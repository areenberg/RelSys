This folder contains data and results from the paper entitled: "An approximation to the distribution of inpatients in hospitals with patient relocation". The paper is published in the journal of Computers and Industrial Engineering.

The subfolder "Aggregated data" contains anonymous and aggregated data from a selection of inpatient wards in a hospital. The content can be loaded using the programming language R (using the load() command).

The subfolder "Results" contains detailed results and information about the validation of our approximation.

An implementation of our approximation can be downloaded from GitHub using the link below.

Link: https://github.com/areenberg/RelSys


Anders Reenberg Andersen
Bo Friis Nielsen
Andreas Lindhardt Plesner

July, 2022
